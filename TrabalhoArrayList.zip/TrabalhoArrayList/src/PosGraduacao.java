import java.util.Date;

public class PosGraduacao extends Aluno{
	
	private String semestreQualificacao;
	private Date dataDefesa;
	
	public PosGraduacao(){
		
	}
	
	public PosGraduacao(int matricula, String nome, String semestreIngresso, String semestreQualificacao, Date dataDefesa) {
		super(matricula, nome, semestreIngresso);
		this.semestreQualificacao = semestreQualificacao;
		this.dataDefesa = dataDefesa;
	}

	public String getSemestreQualificacao() {
		return semestreQualificacao;
	}

	public Date getDataDefesa() {
		return dataDefesa;
	}
	
	
	
}
