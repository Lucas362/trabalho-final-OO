
public class Auxiliar extends Professor{
	
	private String graduacao;
	private int anoGraduacao;
	
	public Auxiliar(){
		
	}
	
	public Auxiliar(int matriculaSiape, int matriculaFUB, String formacao, float salario, String graduacao, int anoGraduacao) {
		super(matriculaSiape, matriculaFUB, formacao, salario);
		this.graduacao = graduacao;
		this.anoGraduacao = anoGraduacao;
	}

	public String getGraduacao() {
		return graduacao;
	}

	public int getAnoGraduacao() {
		return anoGraduacao;
	}
		
}
