

public class InformacaoFaltanteException extends Exception{

	public InformacaoFaltanteException(){
		super("Falta informação");
	}
}
