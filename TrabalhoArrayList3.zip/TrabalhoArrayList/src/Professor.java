
public class Professor {
	
	private int matriculaSiape;
	private int matriculaFUB;
	private String formacao;
	private float salario;
	
	public Professor(){
		
	}
	
	public Professor(int matriculaSiape, int matriculaFUB, String formacao, float salario) {
		this.matriculaSiape = matriculaSiape;
		this.matriculaFUB = matriculaFUB;
		this.formacao = formacao;
		this.salario = salario;
	}

	public int getMatriculaSiape() {
		return matriculaSiape;
	}

	public int getMatriculaFUB() {
		return matriculaFUB;
	}

	public String getFormacao() {
		return formacao;
	}

	public float getSalario() {
		return salario;
	}
	
	
	
}
