
public class Turma {
	
	private int codigo;
	private String horario;
	private String disciplina;
	private String professor;
	
	public Turma(){
		
	}
	
	public Turma(int codigo, String horario, String disciplina, String professor) {
		this.codigo = codigo;
		this.horario = horario;
		this.disciplina = disciplina;
		this.professor = professor;
	}

	public int getCodigo() {
		return codigo;
	}

	public String getHorario() {
		return horario;
	}
	
	public String getDisciplina() {
		return disciplina;
	}
	
	public String getProfessor() {
		return professor;
	}
		
}
