
public class Aluno {
	
	private int matricula;
	private String nome;
	private String semestreIngresso;
	
	public Aluno(){
		
	}
	
	public Aluno(int matricula, String nome, String semestreIngresso) {
		this.matricula = matricula;
		this.nome = nome;
		this.semestreIngresso = semestreIngresso;
	}

	public int getMatricula() {
		return matricula;
	}

	public String getNome() {
		return nome;
	}

	public String getSemestreIngresso() {
		return semestreIngresso;
	}
	
	
	
	
}
