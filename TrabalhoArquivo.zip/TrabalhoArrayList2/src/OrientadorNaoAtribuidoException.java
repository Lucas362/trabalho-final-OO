
public class OrientadorNaoAtribuidoException extends Exception {
	public OrientadorNaoAtribuidoException(){
		
	}
}
