
public class DisciplinaNaoAtribuidaException extends Exception {
	public DisciplinaNaoAtribuidaException(){
		
	}
}
