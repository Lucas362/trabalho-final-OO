import java.util.Date;

public class Especial extends PosGraduacao{
	
	private boolean taxaPaga;
	private String semestreCursado;
	private String professor;
	
	public Especial(){
		
	}
	
	public Especial(int matricula, String nome, String semestreIngresso, String semestreQualificacao, Date dataDefesa,
										boolean taxaPaga, String semestreCursado, String professor) {
		super(matricula, nome, semestreIngresso, semestreQualificacao, dataDefesa, professor);
		this.taxaPaga = taxaPaga;
		this.semestreCursado = semestreCursado;
		this.professor = professor;
	}

	public boolean isTaxaPaga() {
		return taxaPaga;
	}

	public String getSemestreCursado() {
		return semestreCursado;
	}
		
}
