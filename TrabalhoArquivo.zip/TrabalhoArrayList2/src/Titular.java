import java.util.Date;

public class Titular extends Associado{
	
	private Date concurso;
	private Date dataDeAdmissao;
	
	public Titular(){
		
	}
	
	public Titular(int matriculaSiape, int matriculaFUB, String formacao, float salario, String graduacao, int anoGraduacao, 
			String mestrado, int anoMestrado, String tituloDissertacao, String doutorado, int anoDoutorado, 
			String tituloTese, String areaDePesquisa, Date concurso, Date dataDeAdmissao) {
		super(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao, mestrado, anoMestrado,
				tituloDissertacao, doutorado, anoDoutorado, tituloTese, areaDePesquisa);
		this.concurso = concurso;
		this.dataDeAdmissao = dataDeAdmissao;
	}

	public Date getConcurso() {
		return concurso;
	}

	public Date getDataDeAdmissao() {
		return dataDeAdmissao;
	}
		
}
