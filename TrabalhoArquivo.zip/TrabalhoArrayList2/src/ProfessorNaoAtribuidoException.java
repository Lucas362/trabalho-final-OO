
public class ProfessorNaoAtribuidoException extends Exception {
	public ProfessorNaoAtribuidoException(){
		
	}
}
