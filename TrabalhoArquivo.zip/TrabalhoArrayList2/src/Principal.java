import java.awt.HeadlessException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) throws HeadlessException, ParseException{

		int op = 1;
		
		BufferedWriter writer = null;

		while(op!=0){
			try{
				String result = JOptionPane.showInputDialog("----Digite uma das opções abaixo----\n\n"
						+ " 1 - Cadastrar aluno de graduação\n"
						+ " 2 - Cadastrar aluno de pos-graduação\n"
						+ " 3 - Cadastrar aluno especial\n"
						+ " 4 - Cadastrar professor auxiliar\n"
						+ " 5 - Cadastrar professor assistente\n"
						+ " 6 - Cadastrar professor adjunto\n"
						+ " 7 - Cadastrar professor associado\n"
						+ " 8 - Cadastrar professor titular\n"
						+ " 9 - Cadastrar Disciplina\n"
						+ "10 - Cadastrar Estágio\n"
						+ "11 - Cadastrar Turma\n"
						+ " 0 - Sair");
				if(result == null){
					op = 0;
				}else{
					op = Integer.parseInt(result);
				}
			}catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Digite somente números");
				op = 20;
			}
			switch(op){
			case 1:
				try{
					SimpleDateFormat inputFormat = new SimpleDateFormat("dd/mm/yy");
					String matriculaS = JOptionPane.showInputDialog("Digite a matricula do aluno");
					if(matriculaS==null || matriculaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matricula = Integer.parseInt(matriculaS);
					String nome = JOptionPane.showInputDialog("Digite o nome do aluno");
					if(nome==null || nome.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String semestreIngresso = JOptionPane.showInputDialog("Digite o semestre de ingresso do aluno");
					if(semestreIngresso==null || semestreIngresso.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String formaIngresso = JOptionPane.showInputDialog("Digite a forma de ingresso do aluno");
					if(formaIngresso==null || formaIngresso.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String curso = JOptionPane.showInputDialog("Digite o curso do aluno");
					if(curso==null || curso.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String provavelFormaturaS = JOptionPane.showInputDialog("Digite a provavel data de "
							+ "formatura do aluno (formato: dd/mm/aa)");
					if(provavelFormaturaS==null || provavelFormaturaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					Date provavelFormatura = inputFormat.parse(provavelFormaturaS);
					Graduacao g = new Graduacao(matricula, nome, semestreIngresso, formaIngresso, curso, provavelFormatura);
					
					File alunog = new File("alunoGraducao.txt");
					if(!alunog.exists()){
						alunog.createNewFile();
					}
					
					String dados = "------Aluno------";
					dados+="\nMatricula: "+Integer.toString(g.getMatricula());
					dados+="\nNome: "+g.getNome();
					dados+="\nSemestre de ingresso: "+g.getSemestreIngresso();
					dados+="\nForma de ingresso: "+g.getFormaIngresso();
					dados+="\nCurso: "+g.getCurso();
					dados+="\nData da provável formatura: "+inputFormat.format(g.getProvavelFormatura())+"\n";
					
					FileWriter fileWriter = new FileWriter(alunog, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException ag) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(ParseException e){
					JOptionPane.showMessageDialog(null, "formato de data incorreta (formato: dd/mm/aa)!");
					
				}catch(NumberFormatException e1){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
					
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Aluno Graduacao!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}

				break;
			case 2:
				try{
					SimpleDateFormat inputFormat = new SimpleDateFormat("dd/mm/yy");
					String matriculaS = JOptionPane.showInputDialog("Digite a matricula do aluno");
					if(matriculaS==null || matriculaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matricula = Integer.parseInt(matriculaS);
					String nome = JOptionPane.showInputDialog("Digite o nome do aluno");
					if(nome==null || nome.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String semestreIngresso = JOptionPane.showInputDialog("Digite o semestre de ingresso do aluno");
					if(semestreIngresso==null || semestreIngresso.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String semestreQualificacao = JOptionPane.showInputDialog("Digite o semestre de qualificação do aluno");
					if(semestreQualificacao==null || semestreQualificacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String dataDefesaS = JOptionPane.showInputDialog("Digite a provavel data de formatura do aluno (formato: dd/mm/aa)");
					if(dataDefesaS==null || dataDefesaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					Date dataDefesa = inputFormat.parse(dataDefesaS);
					String profOri = JOptionPane.showInputDialog("Digite o nome do professor orientador");
					if(profOri==null || profOri.isEmpty()){
						throw new OrientadorNaoAtribuidoException();
					}
					PosGraduacao pg = new PosGraduacao(matricula, nome, semestreIngresso, semestreQualificacao, dataDefesa, profOri);

					File alunopg = new File("alunoPosGraduacao.txt");
					
					if(!alunopg.exists()){
						alunopg.createNewFile();
					}
						
					String dados = "------Aluno------";
					dados+="\nMatricula: "+Integer.toString(pg.getMatricula());
					dados+="\nNome: "+pg.getNome();
					dados+="\nSemestre de ingresso: "+pg.getSemestreIngresso();
					dados+="\nSemestre da qualificação: "+pg.getSemestreQualificacao();
					dados+="\nData da provável formatura: "+inputFormat.format(pg.getDataDefesa());
					dados+="\nProfessor Orientador: "+pg.getProfessor()+"\n";
						
					FileWriter fileWriter = new FileWriter(alunopg, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
					
				} catch(IOException ap) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(ParseException e){
					JOptionPane.showMessageDialog(null, "formato de data incorreta!");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Aluno Pos Graduacao!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}catch(OrientadorNaoAtribuidoException e){
					JOptionPane.showMessageDialog(null, "Professor nao atribuido para aluno de pos graduacao!");
				}
				break;
			case 3:
				try{
					SimpleDateFormat inputFormat = new SimpleDateFormat("dd/mm/yy");
					String matriculaS = JOptionPane.showInputDialog("Digite a matricula do aluno");
					if(matriculaS==null || matriculaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matricula = Integer.parseInt(matriculaS);
					String nome = JOptionPane.showInputDialog("Digite o nome do aluno");
					if(nome==null || nome.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String semestreIngresso = JOptionPane.showInputDialog("Digite o semestre de ingresso do aluno");
					if(semestreIngresso==null || semestreIngresso.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String semestreQualificacao = JOptionPane.showInputDialog("Digite o semestre de qualificação do aluno");
					if(semestreQualificacao==null || semestreQualificacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String dataDefesaS = JOptionPane.showInputDialog("Digite a provavel data de formatura do aluno (formato: dd/mm/aa)");
					if(dataDefesaS==null || dataDefesaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					Date dataDefesa = inputFormat.parse(dataDefesaS);
					String taxaPagaS = JOptionPane.showInputDialog("Pagou taxa? (True ou False)");
					if(taxaPagaS==null || taxaPagaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					boolean taxaPaga = Boolean.parseBoolean(taxaPagaS);
					String semestreCursado  = JOptionPane.showInputDialog("Digite semestre cursado");
					if(semestreCursado==null || semestreCursado.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String profOri = JOptionPane.showInputDialog("Digite o nome do professor orientador");
					if(profOri==null || profOri.isEmpty()){
						throw new OrientadorNaoAtribuidoException();
					}
	
					Especial e = new Especial(matricula, nome, semestreIngresso, semestreQualificacao, dataDefesa, taxaPaga, semestreCursado, profOri);
					
					File alunoe = new File("alunoEspecial.txt");
					if(!alunoe.exists()){
						alunoe.createNewFile();
					}
					
					String dados = "------Aluno------";
					dados+="\nMatricula: "+Integer.toString(e.getMatricula());
					dados+="\nNome: "+e.getNome();
					dados+="\nSemestre de ingresso: "+e.getSemestreIngresso();
					dados+="\nSemestre da qualificação: "+e.getSemestreQualificacao();
					dados+="\nData da provável formatura: "+inputFormat.format(e.getDataDefesa());
					dados+="\nTaxa: "+Boolean.toString(e.isTaxaPaga());
					dados+="\nSemestre cursado: "+e.getSemestreCursado();
					dados+="\nProfessor Orientador: "+e.getProfessor()+"\n";
					
					FileWriter fileWriter = new FileWriter(alunoe, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
					
				} catch(IOException ae) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(ParseException e){
					JOptionPane.showMessageDialog(null, "formato de data incorreta (formato: dd/mm/aa)!");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Aluno Especial!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}catch(OrientadorNaoAtribuidoException e){
					JOptionPane.showMessageDialog(null, "Professor nao atribuido para aluno de pos graduacao!");
				}
				break; 	
			case 4:
				try{
					String matriculaSiapeS = JOptionPane.showInputDialog("Digite a matricula Siape do professor");
					if(matriculaSiapeS==null || matriculaSiapeS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaSiape = Integer.parseInt(matriculaSiapeS);
					String matriculaFUBS = JOptionPane.showInputDialog("Digite a matricula FUB do professor");
					if(matriculaFUBS==null || matriculaFUBS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaFUB = Integer.parseInt(matriculaFUBS);
					String formacao = JOptionPane.showInputDialog("Digite a formação do professor");
					if(formacao==null || formacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String salarioS = JOptionPane.showInputDialog("Digite o salário do professor");
					if(salarioS==null || salarioS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					float salario = Float.parseFloat(salarioS);
					String graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
					if(graduacao==null || graduacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoGraduacaoS = JOptionPane.showInputDialog("Digite o ano de graduação do professor");
					if(anoGraduacaoS==null || anoGraduacaoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoGraduacao = Integer.parseInt(anoGraduacaoS);
					
					Auxiliar a = new Auxiliar(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao);
					
					File professorau = new File("professorAuxiliar.txt");
					if(!professorau.exists()){
						professorau.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(a.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(a.getMatriculaFUB());
					dados+="\nFormação: "+a.getFormacao();
					dados+="\nSalário: "+Float.toString(a.getSalario());
					dados+="\nGraduação: "+a.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(a.getAnoGraduacao())+"\n";
					
					FileWriter fileWriter = new FileWriter(professorau, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException paux) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Professor Auxiliar!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}
				break;
			case 5:
				try{
					String matriculaSiapeS = JOptionPane.showInputDialog("Digite a matricula Siape do professor");
					if(matriculaSiapeS==null || matriculaSiapeS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaSiape = Integer.parseInt(matriculaSiapeS);
					String matriculaFUBS = JOptionPane.showInputDialog("Digite a matricula FUB do professor");
					if(matriculaFUBS==null || matriculaFUBS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaFUB = Integer.parseInt(matriculaFUBS);
					String formacao = JOptionPane.showInputDialog("Digite a formação do professor");
					if(formacao==null || formacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String salarioS = JOptionPane.showInputDialog("Digite o salário do professor");
					if(salarioS==null || salarioS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					float salario = Float.parseFloat(salarioS);
					String graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
					if(graduacao==null || graduacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoGraduacaoS = JOptionPane.showInputDialog("Digite o ano de graduação do professor");
					if(anoGraduacaoS==null || anoGraduacaoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoGraduacao = Integer.parseInt(anoGraduacaoS);
					String mestrado = JOptionPane.showInputDialog("Digite o mestrado do professor");
					if(mestrado==null || mestrado.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoMestradoS = JOptionPane.showInputDialog("Digite o ano do mestrado do professor");
					if(anoMestradoS==null || anoMestradoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoMestrado = Integer.parseInt(anoMestradoS);
					String tituloDissertacao = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
					if(tituloDissertacao==null || tituloDissertacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
	
					Assistente as = new Assistente(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao, mestrado, anoMestrado, tituloDissertacao);
					
					File professoras = new File("professorAssistente.txt");
					if(!professoras.exists()){
						professoras.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(as.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(as.getMatriculaFUB());
					dados+="\nFormação: "+as.getFormacao();
					dados+="\nSalário: "+Float.toString(as.getSalario());
					dados+="\nGraduação: "+as.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(as.getAnoGraduacao());
					dados+="\nMestrado: "+as.getMestrado();
					dados+="\nAno do mestrado: "+Integer.toString(as.getAnoMestrado());
					dados+="\nTítulo da dissertação: "+as.getTituloDissertacao()+"\n";
					
					FileWriter fileWriter = new FileWriter(professoras, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException pas) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Professor Assistente!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}
				break;
			case 6:
				try{
					String matriculaSiapeS = JOptionPane.showInputDialog("Digite a matricula Siape do professor");
					if(matriculaSiapeS==null || matriculaSiapeS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaSiape = Integer.parseInt(matriculaSiapeS);
					String matriculaFUBS = JOptionPane.showInputDialog("Digite a matricula FUB do professor");
					if(matriculaFUBS==null || matriculaFUBS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaFUB = Integer.parseInt(matriculaFUBS);
					String formacao = JOptionPane.showInputDialog("Digite a formação do professor");
					if(formacao==null || formacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String salarioS = JOptionPane.showInputDialog("Digite o salário do professor");
					if(salarioS==null || salarioS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					float salario = Float.parseFloat(salarioS);
					String graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
					if(graduacao==null || graduacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoGraduacaoS = JOptionPane.showInputDialog("Digite o ano de graduação do professor");
					if(anoGraduacaoS==null || anoGraduacaoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoGraduacao = Integer.parseInt(anoGraduacaoS);
					String mestrado = JOptionPane.showInputDialog("Digite o mestrado do professor");
					if(mestrado==null || mestrado.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoMestradoS = JOptionPane.showInputDialog("Digite o ano do mestrado do professor");
					if(anoMestradoS==null || anoMestradoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoMestrado = Integer.parseInt(anoMestradoS);
					String tituloDissertacao = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
					if(tituloDissertacao==null || tituloDissertacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String doutorado = JOptionPane.showInputDialog("Digite o mestrado do professor");
					if(doutorado==null || doutorado.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoDoutoradoS = JOptionPane.showInputDialog("Digite o ano do mestrado do professor");
					if(anoDoutoradoS==null || anoDoutoradoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoDoutorado = Integer.parseInt(anoDoutoradoS);
					String tituloTese = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
					if(tituloTese==null || tituloTese.isEmpty()){
						throw new InformacaoFaltanteException();
					}
	
					Adjunto adj = new Adjunto(matriculaSiape, matriculaFUB, formacao, salario, graduacao,
							anoGraduacao, mestrado, anoMestrado, tituloDissertacao, doutorado,
							anoDoutorado, tituloTese);
					
					File professorad = new File("professorAdjunto.txt");
					if(!professorad.exists()){
						professorad.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(adj.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(adj.getMatriculaFUB());
					dados+="\nFormação: "+adj.getFormacao();
					dados+="\nSalário: "+Float.toString(adj.getSalario());
					dados+="\nGraduação: "+adj.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(adj.getAnoGraduacao());
					dados+="\nMestrado: "+adj.getMestrado();
					dados+="\nAno do mestrado: "+Integer.toString(adj.getAnoMestrado());
					dados+="\nTítulo da dissertação: "+adj.getTituloDissertacao();
					dados+="\nDoutorado: "+adj.getDoutorado();
					dados+="\nAno do doutorado: "+Integer.toString(adj.getAnoDoutorado());
					dados+="\nTítulo da tese: "+adj.getTituloTese()+"\n";
					
					FileWriter fileWriter = new FileWriter(professorad, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException padj) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Professor Adjunto!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}
				break;
			case 7:
				try{
					String matriculaSiapeS = JOptionPane.showInputDialog("Digite a matricula Siape do professor");
					if(matriculaSiapeS==null || matriculaSiapeS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaSiape = Integer.parseInt(matriculaSiapeS);
					String matriculaFUBS = JOptionPane.showInputDialog("Digite a matricula FUB do professor");
					if(matriculaFUBS==null || matriculaFUBS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaFUB = Integer.parseInt(matriculaFUBS);
					String formacao = JOptionPane.showInputDialog("Digite a formação do professor");
					if(formacao==null || formacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String salarioS = JOptionPane.showInputDialog("Digite o salário do professor");
					if(salarioS==null || salarioS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					float salario = Float.parseFloat(salarioS);
					String graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
					if(graduacao==null || graduacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoGraduacaoS = JOptionPane.showInputDialog("Digite o ano de graduação do professor");
					if(anoGraduacaoS==null || anoGraduacaoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoGraduacao = Integer.parseInt(anoGraduacaoS);
					String mestrado = JOptionPane.showInputDialog("Digite o mestrado do professor");
					if(mestrado==null || mestrado.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoMestradoS = JOptionPane.showInputDialog("Digite o ano do mestrado do professor");
					if(anoMestradoS==null || anoMestradoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoMestrado = Integer.parseInt(anoMestradoS);
					String tituloDissertacao = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
					if(tituloDissertacao==null || tituloDissertacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String doutorado = JOptionPane.showInputDialog("Digite o mestrado do professor");
					if(doutorado==null || doutorado.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoDoutoradoS = JOptionPane.showInputDialog("Digite o ano do mestrado do professor");
					if(anoDoutoradoS==null || anoDoutoradoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoDoutorado = Integer.parseInt(anoDoutoradoS);
					String tituloTese = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
					if(tituloTese==null || tituloTese.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String areaDePesquisa = JOptionPane.showInputDialog("Digite a área de pesquisa do professor");
					if(areaDePesquisa==null || areaDePesquisa.isEmpty()){
						throw new InformacaoFaltanteException();
					}
	
					Associado asd = new Associado(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao, 
							mestrado, anoMestrado, tituloDissertacao, doutorado, anoDoutorado, tituloTese, areaDePesquisa);
					
					File professorasd = new File("professorAssociado.txt");
					if(!professorasd.exists()){
						professorasd.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(asd.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(asd.getMatriculaFUB());
					dados+="\nFormação: "+asd.getFormacao();
					dados+="\nSalário: "+Float.toString(asd.getSalario());
					dados+="\nGraduação: "+asd.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(asd.getAnoGraduacao());
					dados+="\nMestrado: "+asd.getMestrado();
					dados+="\nAno do mestrado: "+Integer.toString(asd.getAnoMestrado());
					dados+="\nTítulo da dissertação: "+asd.getTituloDissertacao();
					dados+="\nDoutorado: "+asd.getDoutorado();
					dados+="\nAno do doutorado: "+Integer.toString(asd.getAnoDoutorado());
					dados+="\nTítulo da tese: "+asd.getTituloTese();
					dados+="\nÁrea de pesquisa: "+asd.getAreaDePesquisa()+"\n";
					
					FileWriter fileWriter = new FileWriter(professorasd, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException pasd) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Professor Associado!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}
				
				break;
			case 8:
				try{
					SimpleDateFormat inputFormat = new SimpleDateFormat("dd/mm/yy");
					String matriculaSiapeS = JOptionPane.showInputDialog("Digite a matricula Siape do professor");
					if(matriculaSiapeS==null || matriculaSiapeS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaSiape = Integer.parseInt(matriculaSiapeS);
					String matriculaFUBS = JOptionPane.showInputDialog("Digite a matricula FUB do professor");
					if(matriculaFUBS==null || matriculaFUBS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int matriculaFUB = Integer.parseInt(matriculaFUBS);
					String formacao = JOptionPane.showInputDialog("Digite a formação do professor");
					if(formacao==null || formacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String salarioS = JOptionPane.showInputDialog("Digite o salário do professor");
					if(salarioS==null || salarioS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					float salario = Float.parseFloat(salarioS);
					String graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
					if(graduacao==null || graduacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoGraduacaoS = JOptionPane.showInputDialog("Digite o ano de graduação do professor");
					if(anoGraduacaoS==null || anoGraduacaoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoGraduacao = Integer.parseInt(anoGraduacaoS);
					String mestrado = JOptionPane.showInputDialog("Digite o mestrado do professor");
					if(mestrado==null || mestrado.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoMestradoS = JOptionPane.showInputDialog("Digite o ano do mestrado do professor");
					if(anoMestradoS==null || anoMestradoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoMestrado = Integer.parseInt(anoMestradoS);
					String tituloDissertacao = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
					if(tituloDissertacao==null || tituloDissertacao.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String doutorado = JOptionPane.showInputDialog("Digite o mestrado do professor");
					if(doutorado==null || doutorado.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String anoDoutoradoS = JOptionPane.showInputDialog("Digite o ano do mestrado do professor");
					if(anoDoutoradoS==null || anoDoutoradoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int anoDoutorado = Integer.parseInt(anoDoutoradoS);
					String tituloTese = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
					if(tituloTese==null || tituloTese.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String areaDePesquisa = JOptionPane.showInputDialog("Digite a área de pesquisa do professor");
					if(areaDePesquisa==null || areaDePesquisa.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String concursoS = JOptionPane.showInputDialog("Digite a data do concurso do professor (formato: dd/mm/aa)");
					if(concursoS==null || concursoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					Date concurso = inputFormat.parse(concursoS);
					String dataDeAdmissaoS = JOptionPane.showInputDialog("Digite a data de admissão do professor (formato: dd/mm/aa)");
					if(dataDeAdmissaoS==null || dataDeAdmissaoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					Date dataDeAdmissao = inputFormat.parse(dataDeAdmissaoS);
	
					Titular t = new Titular(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao, 
							mestrado, anoMestrado, tituloDissertacao, doutorado, anoDoutorado, 
							tituloTese, areaDePesquisa, concurso, dataDeAdmissao);
					
					File professort = new File("professorTitular.txt");
					if(!professort.exists()){
						professort.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(t.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(t.getMatriculaFUB());
					dados+="\nFormação: "+t.getFormacao();
					dados+="\nSalário: "+Float.toString(t.getSalario());
					dados+="\nGraduação: "+t.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(t.getAnoGraduacao());
					dados+="\nMestrado: "+t.getMestrado();
					dados+="\nAno do mestrado: "+Integer.toString(t.getAnoMestrado());
					dados+="\nTítulo da dissertação: "+t.getTituloDissertacao();
					dados+="\nDoutorado: "+t.getDoutorado();
					dados+="\nAno do doutorado: "+Integer.toString(t.getAnoDoutorado());
					dados+="\nTítulo da tese: "+t.getTituloTese();
					dados+="\nÁrea de pesquisa: "+t.getAreaDePesquisa();
					dados+="\nData do concurso: "+inputFormat.format(t.getConcurso());
					dados+="\nData de admissão: "+inputFormat.format(t.getDataDeAdmissao())+"\n";
					
					FileWriter fileWriter = new FileWriter(professort, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException pt) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(ParseException e){
					JOptionPane.showMessageDialog(null, "formato de data incorreta (formato: dd/mm/aa)!");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Professor Titular!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}

				break;
			case 9:
				try{
					String nome = JOptionPane.showInputDialog("Digite o nome da disciplina");
					if(nome==null || nome.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String cargaHorariaS = JOptionPane.showInputDialog("Digite a carga horária da disciplina");
					if(cargaHorariaS==null || cargaHorariaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int cargaHoraria = Integer.parseInt(cargaHorariaS);
					
					Disciplina d = new Disciplina(nome, cargaHoraria);
					
					File disc = new File("Disciplina.txt");
					if(!disc.exists()){
						disc.createNewFile();
					}
					
					String dados = "------Disciplina------";
					dados+="\nNome: "+d.getNome();
					dados+="\nCarga horária: "+Integer.toString(d.getCargaHoraria())+"\n";
					
					FileWriter fileWriter = new FileWriter(disc, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException di) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Disciplina!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}
				break;
			case 10:
				try{
					String nome = JOptionPane.showInputDialog("Digite o nome do estágio");
					if(nome==null || nome.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String cargaHorariaS = JOptionPane.showInputDialog("Digite a carga horária do estágio");
					if(cargaHorariaS==null || cargaHorariaS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int cargaHoraria = Integer.parseInt(cargaHorariaS);
					String localDeEstagio = JOptionPane.showInputDialog("Digite o local do estágio");
					if(localDeEstagio==null || localDeEstagio.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String responsavel = JOptionPane.showInputDialog("Digite o nome do responsável pelo estágio");
					if(responsavel==null || responsavel.isEmpty()){
						throw new InformacaoFaltanteException();
					}
	
					Estagio es = new Estagio(nome, cargaHoraria, localDeEstagio, responsavel);
					
					File est = new File("estagio.txt");
					if(!est.exists()){
						est.createNewFile();
					}
					
					String dados = "------Estagio------";
					dados+="\nNome: "+es.getNome();
					dados+="\nCarga horária: "+Integer.toString(es.getCargaHoraria());
					dados+="\nLocal de estágio: "+es.getLocalDeEstagio();
					dados+="\nResponsável: "+es.getResponsavel()+"\n";
					
					FileWriter fileWriter = new FileWriter(est, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException ag) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Estágio!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}
				break;
			case 11:
				try{
					String codigoS = JOptionPane.showInputDialog("Digite o código da turma");
					if(codigoS==null || codigoS.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					int codigo = Integer.parseInt(codigoS);
					String horario = JOptionPane.showInputDialog("Digite o horário da turma");
					if(horario==null || horario.isEmpty()){
						throw new InformacaoFaltanteException();
					}
					String professor = JOptionPane.showInputDialog("Digite o nome do professor da turma: ");
					if(professor==null || professor.isEmpty()){
						throw new ProfessorNaoAtribuidoException();
					}
					String disciplina = JOptionPane.showInputDialog("Digite o nome da disciplina da turma: ");
					if(disciplina==null || disciplina.isEmpty()){
						throw new DisciplinaNaoAtribuidaException();
					}
					Turma tu = new Turma(codigo, horario, disciplina, professor);
					
					File turma = new File("estagio.txt");
					if(!turma.exists()){
						turma.createNewFile();
					}
					
					String dados = "------Turma------";
					dados+="\nCódigo: "+Integer.toString(tu.getCodigo());
					dados+="\nHorário: "+tu.getHorario();
					dados+="\nProfessor: "+tu.getHorario();
					dados+="\nDisciplina: "+tu.getHorario()+"\n";
					
					FileWriter fileWriter = new FileWriter(turma, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException tur) {
					System.out.println("Não foi possível gravar o arquivo");
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "entrada não permitida");
				}catch(InformacaoFaltanteException e2){
					JOptionPane.showMessageDialog(null, "Informacao faltando na classe Turma!");
					System.out.println("Informacao faltando na classe Aluno Especial!");
				}catch(DisciplinaNaoAtribuidaException e3){
					JOptionPane.showMessageDialog(null, "Disciplina faltando na classe Turma!");
				}catch(ProfessorNaoAtribuidoException e4){
					JOptionPane.showMessageDialog(null, "Professor faltando na classe Turma!");
				}
				break;
			case 0:
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida!");

			}
		}

	}
}