import java.util.Date;

public class PosGraduacao extends Aluno{
	
	private String semestreQualificacao;
	private Date dataDefesa;
	private String professor;
	
	public PosGraduacao(){
		
	}
	
	public PosGraduacao(int matricula, String nome, String semestreIngresso, String semestreQualificacao, Date dataDefesa, String professor) {
		super(matricula, nome, semestreIngresso);
		this.semestreQualificacao = semestreQualificacao;
		this.dataDefesa = dataDefesa;
		this.professor = professor;
	}

	public String getSemestreQualificacao() {
		return semestreQualificacao;
	}

	public Date getDataDefesa() {
		return dataDefesa;
	}
	
	public String getProfessor() {
		return professor;
	}	
	
}
