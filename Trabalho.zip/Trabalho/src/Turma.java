
public class Turma {
	
	private int codigo;
	private String horario;
	
	public Turma(){
		
	}
	
	public Turma(int codigo, String horario) {
		this.codigo = codigo;
		this.horario = horario;
	}

	public int getCodigo() {
		return codigo;
	}

	public String getHorario() {
		return horario;
	}
		
}
