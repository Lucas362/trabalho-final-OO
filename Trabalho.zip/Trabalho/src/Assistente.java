
public class Assistente extends Auxiliar{
	
	private String mestrado;
	private int anoMestrado;
	private String tituloDissertacao;
	
	public Assistente(){
		
	}
	
	public Assistente(int matriculaSiape, int matriculaFUB, String formacao, float salario, String graduacao, int anoGraduacao, String mestrado, int anoMestrado, String tituloDissertacao) {
		super(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao);
		this.mestrado = mestrado;
		this.anoMestrado = anoMestrado;
		this.tituloDissertacao = tituloDissertacao;
	}

	public String getMestrado() {
		return mestrado;
	}

	public int getAnoMestrado() {
		return anoMestrado;
	}

	public String getTituloDissertacao() {
		return tituloDissertacao;
	}
	
}
