
public class Adjunto extends Assistente{
	
	private String doutorado;
	private int anoDoutorado;
	private String tituloTese;
	
	public Adjunto(){
		
	}
	
	public Adjunto(int matriculaSiape, int matriculaFUB, String formacao, float salario, String graduacao,
			int anoGraduacao, String mestrado, int anoMestrado, String tituloDissertacao, String doutorado,
			int anoDoutorado, String tituloTese) {
		super(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao, mestrado, anoMestrado, tituloDissertacao);
		this.doutorado = doutorado;
		this.anoDoutorado = anoDoutorado;
		this.tituloTese = tituloTese;
	}

	public String getDoutorado() {
		return doutorado;
	}

	public int getAnoDoutorado() {
		return anoDoutorado;
	}

	public String getTituloTese() {
		return tituloTese;
	}
		
}
