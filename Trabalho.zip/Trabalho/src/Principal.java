import java.awt.HeadlessException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) throws HeadlessException, ParseException{

		BufferedWriter writer = null;

		int op = 1;

		while(op!=0){
			try{
				String result = JOptionPane.showInputDialog("----Digite uma das opções abaixo----\n\n"
						+ " 1 - Cadastrar aluno de graduação\n"
						+ " 2 - Cadastrar aluno de pos-graduação\n"
						+ " 3 - Cadastrar aluno especial\n"
						+ " 4 - Cadastrar professor auxiliar\n"
						+ " 5 - Cadastrar professor assistente\n"
						+ " 6 - Cadastrar professor adjunto\n"
						+ " 7 - Cadastrar professor associado\n"
						+ " 8 - Cadastrar professor titular\n"
						+ " 9 - Cadastrar Disciplina\n"
						+ "10 - Cadastrar Estágio\n"
						+ "11 - Cadastrar Turma\n"
						+ " 0 - Sair");
				if(result == null){
					op = 0;
				}else{
					op = Integer.parseInt(result);
				}
			}catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Digite somente números");
				op = 20;
			}
			switch(op){
			case 1:

				SimpleDateFormat inputFormat = new SimpleDateFormat("MM/dd/yy");
				int matricula = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula do aluno"));
				String nome = JOptionPane.showInputDialog("Digite o nome do aluno");
				String semestreIngresso = JOptionPane.showInputDialog("Digite o semestre de ingresso do aluno");
				String formaIngresso = JOptionPane.showInputDialog("Digite a forma de ingresso do aluno");
				String curso = JOptionPane.showInputDialog("Digite o curso do aluno");
				Date provavelFormatura = inputFormat.parse(JOptionPane.showInputDialog("Digite a provavel data de "
						+ "formatura do aluno"));
				Graduacao g = new Graduacao(matricula, nome, semestreIngresso, formaIngresso, curso, provavelFormatura);

				File alunog = new File("alunoGraducao.txt");
				try{
					if(!alunog.exists()){
						alunog.createNewFile();
					}
					
					String dados = "------Aluno------";
					dados+="\nMatricula: "+Integer.toString(g.getMatricula());
					dados+="\nNome: "+g.getNome();
					dados+="\nSemestre de ingresso: "+g.getSemestreIngresso();
					dados+="\nForma de ingresso: "+g.getFormaIngresso();
					dados+="\nCurso: "+g.getCurso();
					dados+="\nData da provável formatura: "+inputFormat.format(g.getProvavelFormatura())+"\n";
					
					FileWriter fileWriter = new FileWriter(alunog, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException ag) {
					System.out.println("Não foi possível gravar o arquivo");
				}

				break;
			case 2:
				inputFormat = new SimpleDateFormat("MM/dd/yy");
				matricula = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula do aluno"));
				nome = JOptionPane.showInputDialog("Digite o nome do aluno");
				semestreIngresso = JOptionPane.showInputDialog("Digite o semestre de ingresso do aluno");
				String semestreQualificacao = JOptionPane.showInputDialog("Digite o semestre de qualificação do aluno");
				Date dataDefesa = inputFormat.parse(JOptionPane.showInputDialog("Digite a provavel data de formatura do aluno"));

				PosGraduacao pg = new PosGraduacao(matricula, nome, semestreIngresso, semestreQualificacao, dataDefesa);
				
				File alunopg = new File("alunoPosGraduacao.txt");
				try{
					if(!alunopg.exists()){
						alunopg.createNewFile();
					}
					
					String dados = "------Aluno------";
					dados+="\nMatricula: "+Integer.toString(pg.getMatricula());
					dados+="\nNome: "+pg.getNome();
					dados+="\nSemestre de ingresso: "+pg.getSemestreIngresso();
					dados+="\nSemestre da qualificação: "+pg.getSemestreQualificacao();
					dados+="\nData da provável formatura: "+inputFormat.format(pg.getDataDefesa())+"\n";
					
					FileWriter fileWriter = new FileWriter(alunopg, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException ap) {
					System.out.println("Não foi possível gravar o arquivo");
				}
				break;
			case 3:
				inputFormat = new SimpleDateFormat("MM/dd/yy");
				matricula = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula do aluno"));
				nome = JOptionPane.showInputDialog("Digite o nome do aluno");
				semestreIngresso = JOptionPane.showInputDialog("Digite o semestre de ingresso do aluno");
				semestreQualificacao = JOptionPane.showInputDialog("Digite o semestre de qualificação do aluno");
				dataDefesa = inputFormat.parse(JOptionPane.showInputDialog("Digite a provavel data de formatura do aluno"));
				boolean taxaPaga = Boolean.parseBoolean(JOptionPane.showInputDialog("Pagou taxa? (True ou False)"));
				String semestreCursado  = JOptionPane.showInputDialog("Digite semestre cursado");

				Especial e = new Especial(matricula, nome, semestreIngresso, semestreQualificacao, dataDefesa, taxaPaga, semestreCursado);
				
				File alunoe = new File("alunoEspecial.txt");
				try{
					if(!alunoe.exists()){
						alunoe.createNewFile();
					}
					
					String dados = "------Aluno------";
					dados+="\nMatricula: "+Integer.toString(e.getMatricula());
					dados+="\nNome: "+e.getNome();
					dados+="\nSemestre de ingresso: "+e.getSemestreIngresso();
					dados+="\nSemestre da qualificação: "+e.getSemestreQualificacao();
					dados+="\nData da provável formatura: "+inputFormat.format(e.getDataDefesa());
					dados+="\nTaxa: "+Boolean.toString(e.isTaxaPaga());
					dados+="\nSemestre cursado: "+e.getSemestreCursado();
					
					FileWriter fileWriter = new FileWriter(alunoe, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException ae) {
					System.out.println("Não foi possível gravar o arquivo");
				}
				break; 	
			case 4:
				int matriculaSiape = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula Siape do professor"));
				int matriculaFUB = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula FUB do professor"));
				String formacao = JOptionPane.showInputDialog("Digite a formação do professor");
				float salario = Float.parseFloat(JOptionPane.showInputDialog("Digite o salário do professor"));
				String graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
				int anoGraduacao = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de graduação do professor"));

				Auxiliar a = new Auxiliar(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao);
				
				File professorau = new File("professorAuxiliar.txt");
				try{
					if(!professorau.exists()){
						professorau.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(a.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(a.getMatriculaFUB());
					dados+="\nFormação: "+a.getFormacao();
					dados+="\nSalário: "+Float.toString(a.getSalario());
					dados+="\nGraduação: "+a.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(a.getAnoGraduacao())+"\n";
					
					FileWriter fileWriter = new FileWriter(professorau, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException paux) {
					System.out.println("Não foi possível gravar o arquivo");
				}

				break;
			case 5:
				matriculaSiape = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula Siape do professor"));
				matriculaFUB = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula FUB do professor"));
				formacao = JOptionPane.showInputDialog("Digite a formação do professor");
				salario = Float.parseFloat(JOptionPane.showInputDialog("Digite o salário do professor"));
				graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
				anoGraduacao = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de graduação do professor"));
				String mestrado = JOptionPane.showInputDialog("Digite o mestrado do professor");
				int anoMestrado = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do mestrado do professor"));
				String tituloDissertacao = JOptionPane.showInputDialog("Digite o título da dissertação do professor");

				Assistente as = new Assistente(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao, mestrado, anoMestrado, tituloDissertacao);
				
				File professoras = new File("professorAssistente.txt");
				try{
					if(!professoras.exists()){
						professoras.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(as.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(as.getMatriculaFUB());
					dados+="\nFormação: "+as.getFormacao();
					dados+="\nSalário: "+Float.toString(as.getSalario());
					dados+="\nGraduação: "+as.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(as.getAnoGraduacao());
					dados+="\nMestrado: "+as.getMestrado();
					dados+="\nAno do mestrado: "+Integer.toString(as.getAnoMestrado());
					dados+="\nTítulo da dissertação: "+as.getTituloDissertacao()+"\n";
					
					FileWriter fileWriter = new FileWriter(professoras, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException paux) {
					System.out.println("Não foi possível gravar o arquivo");
				}
				break;
			case 6:
				matriculaSiape = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula Siape do professor"));
				matriculaFUB = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula FUB do professor"));
				formacao = JOptionPane.showInputDialog("Digite a formação do professor");
				salario = Float.parseFloat(JOptionPane.showInputDialog("Digite o salário do professor"));
				graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
				anoGraduacao = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de graduação do professor"));
				mestrado = JOptionPane.showInputDialog("Digite o mestrado do professor");
				anoMestrado = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do mestrado do professor"));
				tituloDissertacao = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
				String doutorado = JOptionPane.showInputDialog("Digite o doutorado do professor");
				int anoDoutorado = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do doutorado do professor"));
				String tituloTese = JOptionPane.showInputDialog("Digite o título da tese do professor");

				Adjunto adj = new Adjunto(matriculaSiape, matriculaFUB, formacao, salario, graduacao,
						anoGraduacao, mestrado, anoMestrado, tituloDissertacao, doutorado,
						anoDoutorado, tituloTese);
				
				File professorad = new File("professorAdjunto.txt");
				try{
					if(!professorad.exists()){
						professorad.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(adj.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(adj.getMatriculaFUB());
					dados+="\nFormação: "+adj.getFormacao();
					dados+="\nSalário: "+Float.toString(adj.getSalario());
					dados+="\nGraduação: "+adj.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(adj.getAnoGraduacao());
					dados+="\nMestrado: "+adj.getMestrado();
					dados+="\nAno do mestrado: "+Integer.toString(adj.getAnoMestrado());
					dados+="\nTítulo da dissertação: "+adj.getTituloDissertacao();
					dados+="\nDoutorado: "+adj.getDoutorado();
					dados+="\nAno do doutorado: "+Integer.toString(adj.getAnoDoutorado());
					dados+="\nTítulo da tese: "+adj.getTituloTese()+"\n";
					
					FileWriter fileWriter = new FileWriter(professorad, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException padj) {
					System.out.println("Não foi possível gravar o arquivo");
				}

				break;
			case 7:
				matriculaSiape = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula Siape do professor"));
				matriculaFUB = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula FUB do professor"));
				formacao = JOptionPane.showInputDialog("Digite a formação do professor");
				salario = Float.parseFloat(JOptionPane.showInputDialog("Digite o salário do professor"));
				graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
				anoGraduacao = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de graduação do professor"));
				mestrado = JOptionPane.showInputDialog("Digite o mestrado do professor");
				anoMestrado = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do mestrado do professor"));
				tituloDissertacao = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
				doutorado = JOptionPane.showInputDialog("Digite o doutorado do professor");
				anoDoutorado = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do doutorado do professor"));
				tituloTese = JOptionPane.showInputDialog("Digite o título da tese do professor");
				String areaDePesquisa = JOptionPane.showInputDialog("Digite a área de pesquisa do professor");

				Associado asd = new Associado(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao, 
						mestrado, anoMestrado, tituloDissertacao, doutorado, anoDoutorado, tituloTese, areaDePesquisa);
				
				File professorasd = new File("professorAssociado.txt");
				try{
					if(!professorasd.exists()){
						professorasd.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(asd.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(asd.getMatriculaFUB());
					dados+="\nFormação: "+asd.getFormacao();
					dados+="\nSalário: "+Float.toString(asd.getSalario());
					dados+="\nGraduação: "+asd.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(asd.getAnoGraduacao());
					dados+="\nMestrado: "+asd.getMestrado();
					dados+="\nAno do mestrado: "+Integer.toString(asd.getAnoMestrado());
					dados+="\nTítulo da dissertação: "+asd.getTituloDissertacao();
					dados+="\nDoutorado: "+asd.getDoutorado();
					dados+="\nAno do doutorado: "+Integer.toString(asd.getAnoDoutorado());
					dados+="\nTítulo da tese: "+asd.getTituloTese();
					dados+="\nÁrea de pesquisa: "+asd.getAreaDePesquisa()+"\n";
					
					FileWriter fileWriter = new FileWriter(professorasd, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException pasd) {
					System.out.println("Não foi possível gravar o arquivo");
				}

				break;
			case 8:
				inputFormat = new SimpleDateFormat("MM/dd/yy");
				matriculaSiape = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula Siape do professor"));
				matriculaFUB = Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula FUB do professor"));
				formacao = JOptionPane.showInputDialog("Digite a formação do professor");
				salario = Float.parseFloat(JOptionPane.showInputDialog("Digite o salário do professor"));
				graduacao = JOptionPane.showInputDialog("Digite a graduação do professor");
				anoGraduacao = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de graduação do professor"));
				mestrado = JOptionPane.showInputDialog("Digite o mestrado do professor");
				anoMestrado = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do mestrado do professor"));
				tituloDissertacao = JOptionPane.showInputDialog("Digite o título da dissertação do professor");
				doutorado = JOptionPane.showInputDialog("Digite o doutorado do professor");
				anoDoutorado = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do doutorado do professor"));
				tituloTese = JOptionPane.showInputDialog("Digite o título da tese do professor");
				areaDePesquisa = JOptionPane.showInputDialog("Digite a área de pesquisa do professor");
				Date concurso = inputFormat.parse(JOptionPane.showInputDialog("Digite a data do concurso do professor"));
				Date dataDeAdmissao = inputFormat.parse(JOptionPane.showInputDialog("Digite a data de admissão do professor"));;


				Titular t = new Titular(matriculaSiape, matriculaFUB, formacao, salario, graduacao, anoGraduacao, 
						mestrado, anoMestrado, tituloDissertacao, doutorado, anoDoutorado, 
						tituloTese, areaDePesquisa, concurso, dataDeAdmissao);
				
				File professort = new File("professorTitular.txt");
				try{
					if(!professort.exists()){
						professort.createNewFile();
					}
					
					String dados = "------Professor------";
					dados+="\nMatricula Siape: "+Integer.toString(t.getMatriculaSiape());
					dados+="\nMatricula FUB: "+Integer.toString(t.getMatriculaFUB());
					dados+="\nFormação: "+t.getFormacao();
					dados+="\nSalário: "+Float.toString(t.getSalario());
					dados+="\nGraduação: "+t.getGraduacao();
					dados+="\nAno da graduação: "+Integer.toString(t.getAnoGraduacao());
					dados+="\nMestrado: "+t.getMestrado();
					dados+="\nAno do mestrado: "+Integer.toString(t.getAnoMestrado());
					dados+="\nTítulo da dissertação: "+t.getTituloDissertacao();
					dados+="\nDoutorado: "+t.getDoutorado();
					dados+="\nAno do doutorado: "+Integer.toString(t.getAnoDoutorado());
					dados+="\nTítulo da tese: "+t.getTituloTese();
					dados+="\nÁrea de pesquisa: "+t.getAreaDePesquisa();
					dados+="\nData do concurso: "+inputFormat.format(t.getConcurso());
					dados+="\nData do concurso: "+inputFormat.format(t.getDataDeAdmissao())+"\n";
					
					FileWriter fileWriter = new FileWriter(professort, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException pt) {
					System.out.println("Não foi possível gravar o arquivo");
				}

				break;
			case 9:
				nome = JOptionPane.showInputDialog("Digite o nome da disciplina");
				int cargaHoraria = Integer.parseInt(JOptionPane.showInputDialog("Digite a carga horária da disciplina"));

				Disciplina d = new Disciplina(nome, cargaHoraria);
				
				File disc = new File("Disciplina.txt");
				try{
					if(!disc.exists()){
						disc.createNewFile();
					}
					
					String dados = "------Disciplina------";
					dados+="\nNome: "+d.getNome();
					dados+="\nCarga horária: "+Integer.toString(d.getCargaHoraria())+"\n";
					
					FileWriter fileWriter = new FileWriter(disc, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException di) {
					System.out.println("Não foi possível gravar o arquivo");
				}

				break;
			case 10:
				nome = JOptionPane.showInputDialog("Digite o nome do estágio");
				cargaHoraria = Integer.parseInt(JOptionPane.showInputDialog("Digite a carga horária do estágio"));
				String localDeEstagio = JOptionPane.showInputDialog("Digite o local do estágio");
				String responsavel = JOptionPane.showInputDialog("Digite o nome do responsável pelo estágio");

				Estagio es = new Estagio(nome, cargaHoraria, localDeEstagio, responsavel);
				
				File est = new File("estagio.txt");
				try{
					if(!est.exists()){
						est.createNewFile();
					}
					
					String dados = "------Estagio------";
					dados+="\nNome: "+es.getNome();
					dados+="\nCarga horária: "+Integer.toString(es.getCargaHoraria());
					dados+="\nLocal de estágio: "+es.getLocalDeEstagio();
					dados+="\nNome: "+es.getResponsavel()+"\n";
					
					FileWriter fileWriter = new FileWriter(est, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException ag) {
					System.out.println("Não foi possível gravar o arquivo");
				}
				
				break;
			case 11:
				int codigo = Integer.parseInt(JOptionPane.showInputDialog("Digite o código da turma"));
				String horario = JOptionPane.showInputDialog("Digite o horário da turma");

				Turma tu = new Turma(codigo, horario);
				
				File turma = new File("estagio.txt");
				try{
					if(!turma.exists()){
						turma.createNewFile();
					}
					
					String dados = "------Turma------";
					dados+="\nCódigo: "+Integer.toString(tu.getCodigo());
					dados+="\nLocal de estágio: "+tu.getHorario()+"\n";
					
					FileWriter fileWriter = new FileWriter(turma, true);
					writer = new BufferedWriter(fileWriter);
					writer.write(dados);
					writer.close();
				} catch(IOException tur) {
					System.out.println("Não foi possível gravar o arquivo");
				}
				break;
			case 0:
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida!");

			}
		}

	}
}
