import java.util.Date;

public class Graduacao extends Aluno{
	
	private String formaIngresso;
	private String curso;
	private Date provavelFormatura;
	
	public Graduacao(){
		
	}
	
	public Graduacao(int matricula, String nome, String semestreIngresso,String formaIngresso, String curso, Date provavelFormatura) {
		super(matricula, nome, semestreIngresso);
		this.formaIngresso = formaIngresso;
		this.curso = curso;
		this.provavelFormatura = provavelFormatura;
	}

	public String getFormaIngresso() {
		return formaIngresso;
	}

	public String getCurso() {
		return curso;
	}

	public Date getProvavelFormatura() {
		return provavelFormatura;
	}
	
	
	
	
}
